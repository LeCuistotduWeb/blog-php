
-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `comment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` (`id`, `author`, `comment`, `comment_date`, `post_id`) VALUES
(5, 'gb', '+1', '2018-02-15 12:21:41', 2),
(7, 'joh', 'test !', '2018-02-15 13:58:18', 1),
(17, 'manu', '+1 !', '2018-02-25 12:07:55', 1),
(18, 'Mak', '+1', '2018-02-25 13:29:02', 1),
(19, 'tom', 'genial !', '2018-02-27 16:01:48', 1),
(20, 'joe', 'super article !\r\n', '2018-02-28 17:30:08', 4),
(21, 'tom', 'je partirais bien moi aussi ;D', '2018-02-28 17:50:52', 4),
(22, 'tom', 'je partirais bien moi aussi ;D', '2018-02-28 17:51:30', 4),
(23, 'tom', 'je partirais bien moi aussi ;D', '2018-02-28 17:51:51', 4),
(24, 'tom', 'je partirais bien moi aussi ;D', '2018-02-28 17:55:55', 4),
(25, 'tom', 'Super ça donne envie.', '2018-02-28 17:56:53', 4),
(26, 'tom', 'Super ça donne envie.', '2018-02-28 17:57:07', 4),
(27, 'tom', 'Super ça donne envie.', '2018-02-28 17:57:19', 4),
(28, 'tom', ' super ca donne envie\r\n', '2018-02-28 17:57:34', 4),
(29, 'tom', ' super ca donne envie\r\n', '2018-02-28 17:59:03', 4),
(30, 'tom', ' super ca donne envie\r\n', '2018-02-28 17:59:43', 4),
(31, 'john', 'super !', '2018-02-28 18:09:10', 3),
(32, 'joe', 'trop bien !', '2018-02-28 18:13:44', 3);
