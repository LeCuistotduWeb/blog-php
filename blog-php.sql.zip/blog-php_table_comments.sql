
-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `comment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `post_id` int(11) NOT NULL,
  `report` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` (`id`, `author`, `comment`, `comment_date`, `post_id`, `report`) VALUES
(5, 'gb', '+1', '2018-02-15 12:21:41', 2, 0),
(17, 'manu', '+1 !', '2018-02-25 12:07:55', 1, 0),
(19, 'tom', 'genial !', '2018-02-27 16:01:48', 1, 0),
(20, 'joe', 'super article !\r\n', '2018-02-28 17:30:08', 4, 0),
(24, 'tom', 'je partirais bien moi aussi ;D', '2018-02-28 17:55:55', 4, 0),
(25, 'tom', 'Super ça donne envie.', '2018-02-28 17:56:53', 4, 0),
(31, 'john', 'super !', '2018-02-28 18:09:10', 3, 0),
(32, 'joe', 'trop bien !', '2018-02-28 18:13:44', 3, 0),
(34, 'jeff', 'bon voyage', '2018-02-28 18:31:17', 2, 0),
(36, 'sophie', 'fais toi plez ! ', '2018-03-01 14:49:27', 2, 0),
(41, 'joe', ':D', '2018-03-01 15:15:28', 2, 0),
(42, 'Matieu', 'bye', '2018-03-01 15:15:42', 2, 0),
(43, 'Matieu', 'bon ovyage !', '2018-03-01 15:20:27', 2, 0),
(44, 'Matieu', 'bon ovyage !', '2018-03-01 15:20:35', 2, 0),
(46, 'jerome', 'les valises, quelles galères. ', '2018-03-01 15:26:21', 1, 0),
(50, 'Mathieu', '+1', '2018-03-01 15:35:25', 1, 0),
(52, 'joe', 'super !', '2018-03-01 15:49:44', 2, 0),
(53, 'fabrice', 'super gagnotte jeux concour sur mon site http://concour.blablabla.fr', '2018-03-01 15:50:27', 2, 1),
(56, 'tom', 'hâte de le lire', '2018-03-05 14:21:01', 13, 0),
(62, 'Mathieu', '<script>alert(\'test\');</script>.', '2018-03-06 17:38:59', 13, 0),
(64, 'dqjulykze', 'fdsjjk', '2018-03-08 16:18:15', 30, 0);
